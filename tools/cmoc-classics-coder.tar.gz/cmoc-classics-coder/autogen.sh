#!/bin/sh

./bootstrap && ./configure "$@"
