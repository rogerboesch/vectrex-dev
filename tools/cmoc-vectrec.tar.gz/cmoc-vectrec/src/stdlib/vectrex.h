// This file is in the public domain.

#ifndef __vectrex_h__
#define __vectrex_h__

#include <vectrex/bios.h>
#include <vectrex/compatibility.h>

#endif
